-- =====================================================================
--  Données d'exemple (facultatif) — pour tester le site tout de suite.
--  À lancer APRÈS schema.sql. Supprimez-les quand vous saisissez les vôtres.
-- =====================================================================

insert into public.articles (name, category, unit, price, stock, min_stock, allergens, supplier) values
  ('Farine T55',            'Farines',       'kg',    0.95,  120, 50, '{gluten}',          'Moulin local'),
  ('Farine T65',            'Farines',       'kg',    1.05,   80, 40, '{gluten}',          'Moulin local'),
  ('Beurre de tourage 82%', 'Crèmerie',      'kg',    9.80,   25, 10, '{lait}',            'Laiterie'),
  ('Lait entier',           'Crèmerie',      'L',     1.15,   30, 10, '{lait}',            'Laiterie'),
  ('Œufs',                  'Crèmerie',      'pièce', 0.28,  360, 120,'{oeufs}',           'Ferme'),
  ('Sucre semoule',         'Épicerie',      'kg',    1.20,   40, 15, '{}',                'Grossiste'),
  ('Sel fin',               'Épicerie',      'kg',    0.60,   10,  3, '{}',                'Grossiste'),
  ('Levure fraîche',        'Épicerie',      'kg',    4.50,    3,  1, '{}',                'Grossiste'),
  ('Chocolat noir 64%',     'Épicerie',      'kg',   14.00,    8,  3, '{soja,lait}',       'Grossiste'),
  ('Poudre de noisette',    'Fruits secs',   'kg',   16.50,    4,  2, '{fruits_coque}',    'Grossiste'),
  ('Graines de sésame',     'Fruits secs',   'kg',    7.20,    2,  1, '{sesame}',          'Grossiste');

with r as (
  insert into public.recipes (name, category, yield_qty, sale_price, traces, instructions) values
    ('Croissant au beurre',  'Viennoiserie', 40, 1.30, '{fruits_coque,sesame}', 'Détrempe, tourage 3 tours simples, détailler, pousser 2h à 26°C, cuire 16 min à 175°C.'),
    ('Pain au chocolat',     'Viennoiserie', 36, 1.50, '{fruits_coque}',        'Même pâte que le croissant, 2 barres de chocolat par pièce.'),
    ('Baguette tradition',   'Pain',         20, 1.40, '{sesame}',              'Pétrissage lent, pointage 1h30, façonnage, apprêt 1h, cuire 22 min à 250°C avec buée.'),
    ('Pain aux graines',     'Pain',          8, 3.60, '{}',                    'Pâte bâtarde, enrober de sésame avant cuisson.')
  returning id, name
)
insert into public.recipe_items (recipe_id, article_id, quantity)
select r.id, a.id, x.qty
from r
join (values
  ('Croissant au beurre', 'Farine T55',            1000),
  ('Croissant au beurre', 'Beurre de tourage 82%',  500),
  ('Croissant au beurre', 'Lait entier',            300),
  ('Croissant au beurre', 'Sucre semoule',          120),
  ('Croissant au beurre', 'Sel fin',                 20),
  ('Croissant au beurre', 'Levure fraîche',          40),
  ('Croissant au beurre', 'Œufs',                     2),
  ('Pain au chocolat',    'Farine T55',            1000),
  ('Pain au chocolat',    'Beurre de tourage 82%',  500),
  ('Pain au chocolat',    'Lait entier',            300),
  ('Pain au chocolat',    'Sucre semoule',          120),
  ('Pain au chocolat',    'Sel fin',                 20),
  ('Pain au chocolat',    'Levure fraîche',          40),
  ('Pain au chocolat',    'Chocolat noir 64%',      350),
  ('Baguette tradition',  'Farine T65',            5000),
  ('Baguette tradition',  'Sel fin',                 90),
  ('Baguette tradition',  'Levure fraîche',          50),
  ('Pain aux graines',    'Farine T65',            3000),
  ('Pain aux graines',    'Sel fin',                 55),
  ('Pain aux graines',    'Levure fraîche',          40),
  ('Pain aux graines',    'Graines de sésame',      250)
) as x(recipe, article, qty) on x.recipe = r.name
join public.articles a on a.name = x.article;

-- Niveaux cibles dans les deux magasins
insert into public.shop_stock (shop_id, recipe_id, qty, target_qty)
select s.id, r.id, 0,
       case r.category when 'Pain' then 30 else 40 end
from public.shops s cross join public.recipes r
on conflict do nothing;

insert into public.production_stock (recipe_id, qty)
select id, 0 from public.recipes on conflict do nothing;
