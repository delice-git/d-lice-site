-- =====================================================================
--  Le Temps d'un Délice — schéma Supabase complet
--  À coller dans Supabase > SQL Editor > New query, puis "Run".
--  Le script peut être relancé sans perte de données.
--
--  Rôles :
--    en_attente  : compte créé mais pas encore validé (aucun accès)
--    magasin     : accès à SON magasin (stock, commandes, allergènes)
--    production  : accès à tout
--    admin       : mêmes droits que la production
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- TABLES
-- ---------------------------------------------------------------------

create table if not exists public.shops (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  address     text,
  created_at  timestamptz not null default now()
);

create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text,
  full_name   text,
  role        text not null default 'en_attente'
              check (role in ('en_attente','magasin','production','admin')),
  shop_id     uuid references public.shops(id) on delete set null,
  created_at  timestamptz not null default now()
);

-- Matières premières (farine, beurre, œufs…)
-- unit = kg, L ou pièce ; price = prix pour 1 unit ; stock exprimé dans unit
create table if not exists public.articles (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  category    text,
  unit        text not null default 'kg' check (unit in ('kg','L','pièce')),
  price       numeric(12,4) not null default 0 check (price >= 0),
  stock       numeric(14,3) not null default 0,
  min_stock   numeric(14,3) not null default 0,
  allergens   text[] not null default '{}',
  supplier    text,
  created_at  timestamptz not null default now()
);

-- Recettes = produits finis vendus en magasin
create table if not exists public.recipes (
  id               uuid primary key default gen_random_uuid(),
  name             text not null,
  category         text,
  yield_qty        numeric(12,2) not null default 1 check (yield_qty > 0), -- pièces par fournée
  sale_price       numeric(10,2) not null default 0,
  extra_allergens  text[] not null default '{}',  -- allergènes ajoutés à la main
  traces           text[] not null default '{}',  -- « peut contenir des traces de »
  instructions     text,
  active           boolean not null default true,
  created_at       timestamptz not null default now()
);

-- Lignes de recette : quantité en g (article en kg), ml (article en L) ou pièces
create table if not exists public.recipe_items (
  id          uuid primary key default gen_random_uuid(),
  recipe_id   uuid not null references public.recipes(id) on delete cascade,
  article_id  uuid not null references public.articles(id) on delete restrict,
  quantity    numeric(14,3) not null check (quantity > 0)
);
create index if not exists recipe_items_recipe_idx on public.recipe_items(recipe_id);

-- Stock de produits finis à la production
create table if not exists public.production_stock (
  recipe_id   uuid primary key references public.recipes(id) on delete cascade,
  qty         numeric(12,2) not null default 0,
  updated_at  timestamptz not null default now()
);

-- Stock de produits finis dans chaque magasin + niveau cible à compléter
create table if not exists public.shop_stock (
  shop_id     uuid not null references public.shops(id) on delete cascade,
  recipe_id   uuid not null references public.recipes(id) on delete cascade,
  qty         numeric(12,2) not null default 0,
  target_qty  numeric(12,2) not null default 0 check (target_qty >= 0),
  updated_at  timestamptz not null default now(),
  primary key (shop_id, recipe_id)
);

create table if not exists public.orders (
  id              bigint generated always as identity primary key,
  shop_id         uuid not null references public.shops(id) on delete restrict,
  created_by      uuid default auth.uid() references auth.users(id) on delete set null,
  kind            text not null default 'reassort' check (kind in ('reassort','client')),
  customer_name   text,
  customer_phone  text,
  due_date        date not null default (current_date + 1),
  status          text not null default 'en_attente'
                  check (status in ('en_attente','en_production','prete','livree','annulee')),
  notes           text,
  delivered_at    timestamptz,
  created_at      timestamptz not null default now()
);
create index if not exists orders_due_idx on public.orders(due_date);
create index if not exists orders_shop_idx on public.orders(shop_id);

create table if not exists public.order_items (
  id          bigint generated always as identity primary key,
  order_id    bigint not null references public.orders(id) on delete cascade,
  recipe_id   uuid not null references public.recipes(id) on delete restrict,
  quantity    numeric(12,2) not null check (quantity > 0)
);
create index if not exists order_items_order_idx on public.order_items(order_id);

-- Agenda de la production
create table if not exists public.events (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  starts_at   timestamptz not null,
  ends_at     timestamptz,
  all_day     boolean not null default false,
  color       text not null default '#b5652b',
  notes       text,
  created_by  uuid default auth.uid() references auth.users(id) on delete set null,
  created_at  timestamptz not null default now()
);

-- Historique des fournées produites
create table if not exists public.production_batches (
  id           bigint generated always as identity primary key,
  recipe_id    uuid references public.recipes(id) on delete set null,
  recipe_name  text,
  batches      numeric(10,2) not null,
  qty          numeric(12,2) not null,
  cost         numeric(12,2),
  produced_by  uuid default auth.uid() references auth.users(id) on delete set null,
  created_at   timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- FONCTIONS D'AIDE (rôle de l'utilisateur connecté)
-- ---------------------------------------------------------------------

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.my_shop() returns uuid
language sql stable security definer set search_path = public as $$
  select shop_id from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role in ('production','admin') from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_active() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role in ('magasin','production','admin') from public.profiles where id = auth.uid()), false)
$$;

-- kg et L : les recettes sont saisies en g / ml
create or replace function public.unit_factor(u text) returns numeric
language sql immutable as $$
  select case when u in ('kg','L') then 1000::numeric else 1::numeric end
$$;

-- Création automatique du profil à chaque nouveau compte
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.email))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- SÉCURITÉ (Row Level Security)
-- ---------------------------------------------------------------------

alter table public.shops              enable row level security;
alter table public.profiles           enable row level security;
alter table public.articles           enable row level security;
alter table public.recipes            enable row level security;
alter table public.recipe_items       enable row level security;
alter table public.production_stock   enable row level security;
alter table public.shop_stock         enable row level security;
alter table public.orders             enable row level security;
alter table public.order_items        enable row level security;
alter table public.events             enable row level security;
alter table public.production_batches enable row level security;

-- Magasins
drop policy if exists shops_read  on public.shops;
drop policy if exists shops_staff on public.shops;
create policy shops_read  on public.shops for select to authenticated using (public.is_active());
create policy shops_staff on public.shops for all    to authenticated using (public.is_staff()) with check (public.is_staff());

-- Profils : chacun voit le sien, la production voit et modifie tout
drop policy if exists profiles_read  on public.profiles;
drop policy if exists profiles_staff on public.profiles;
create policy profiles_read  on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
create policy profiles_staff on public.profiles for all    to authenticated using (public.is_staff()) with check (public.is_staff());

-- Catalogue (lecture pour tous les comptes actifs, écriture production)
drop policy if exists articles_read  on public.articles;
drop policy if exists articles_staff on public.articles;
create policy articles_read  on public.articles for select to authenticated using (public.is_active());
create policy articles_staff on public.articles for all    to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists recipes_read  on public.recipes;
drop policy if exists recipes_staff on public.recipes;
create policy recipes_read  on public.recipes for select to authenticated using (public.is_active());
create policy recipes_staff on public.recipes for all    to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists recipe_items_read  on public.recipe_items;
drop policy if exists recipe_items_staff on public.recipe_items;
create policy recipe_items_read  on public.recipe_items for select to authenticated using (public.is_active());
create policy recipe_items_staff on public.recipe_items for all    to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists production_stock_read  on public.production_stock;
drop policy if exists production_stock_staff on public.production_stock;
create policy production_stock_read  on public.production_stock for select to authenticated using (public.is_active());
create policy production_stock_staff on public.production_stock for all    to authenticated using (public.is_staff()) with check (public.is_staff());

-- Stock magasin : chaque magasin gère le sien
drop policy if exists shop_stock_read   on public.shop_stock;
drop policy if exists shop_stock_staff  on public.shop_stock;
drop policy if exists shop_stock_insert on public.shop_stock;
drop policy if exists shop_stock_update on public.shop_stock;
create policy shop_stock_read   on public.shop_stock for select to authenticated
  using (public.is_staff() or (public.my_role() = 'magasin' and shop_id = public.my_shop()));
create policy shop_stock_staff  on public.shop_stock for all to authenticated
  using (public.is_staff()) with check (public.is_staff());
create policy shop_stock_insert on public.shop_stock for insert to authenticated
  with check (public.my_role() = 'magasin' and shop_id = public.my_shop());
create policy shop_stock_update on public.shop_stock for update to authenticated
  using (public.my_role() = 'magasin' and shop_id = public.my_shop())
  with check (public.my_role() = 'magasin' and shop_id = public.my_shop());

-- Commandes : un magasin voit les siennes et peut annuler celles en attente.
-- La création passe par la fonction create_order().
drop policy if exists orders_read   on public.orders;
drop policy if exists orders_staff  on public.orders;
drop policy if exists orders_cancel on public.orders;
create policy orders_read  on public.orders for select to authenticated
  using (public.is_staff() or (public.my_role() = 'magasin' and shop_id = public.my_shop()));
create policy orders_staff on public.orders for all to authenticated
  using (public.is_staff()) with check (public.is_staff());
create policy orders_cancel on public.orders for update to authenticated
  using (public.my_role() = 'magasin' and shop_id = public.my_shop() and status = 'en_attente')
  with check (public.my_role() = 'magasin' and shop_id = public.my_shop() and status in ('en_attente','annulee'));

drop policy if exists order_items_read  on public.order_items;
drop policy if exists order_items_staff on public.order_items;
create policy order_items_read on public.order_items for select to authenticated
  using (public.is_staff() or exists (
    select 1 from public.orders o
    where o.id = order_id and public.my_role() = 'magasin' and o.shop_id = public.my_shop()));
create policy order_items_staff on public.order_items for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- Agenda et historique : production uniquement
drop policy if exists events_staff  on public.events;
create policy events_staff on public.events for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

drop policy if exists batches_staff on public.production_batches;
create policy batches_staff on public.production_batches for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- ---------------------------------------------------------------------
-- FONCTIONS MÉTIER (appelées depuis le site)
-- ---------------------------------------------------------------------

-- Passer une commande (magasin pour lui-même, production pour n'importe quel magasin)
create or replace function public.create_order(
  p_shop uuid, p_kind text, p_due date, p_items jsonb,
  p_customer_name text default null, p_customer_phone text default null, p_notes text default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare v_id bigint;
begin
  if not (public.is_staff() or (public.my_role() = 'magasin' and public.my_shop() = p_shop)) then
    raise exception 'Vous ne pouvez commander que pour votre magasin';
  end if;
  if p_kind not in ('reassort','client') then
    raise exception 'Type de commande invalide';
  end if;
  if p_kind = 'client' and coalesce(trim(p_customer_name), '') = '' then
    raise exception 'Le nom du client est obligatoire';
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'La commande est vide';
  end if;

  insert into public.orders (shop_id, kind, due_date, customer_name, customer_phone, notes)
  values (p_shop, p_kind, coalesce(p_due, current_date + 1),
          nullif(trim(p_customer_name), ''), nullif(trim(p_customer_phone), ''), nullif(trim(p_notes), ''))
  returning id into v_id;

  insert into public.order_items (order_id, recipe_id, quantity)
  select v_id, (e->>'recipe_id')::uuid, sum((e->>'quantity')::numeric)
  from jsonb_array_elements(p_items) e
  where e->>'recipe_id' is not null and (e->>'quantity')::numeric > 0
  group by (e->>'recipe_id')::uuid;

  if not found then
    raise exception 'La commande est vide';
  end if;
  return v_id;
end $$;

-- Quantités à commander pour remettre un magasin à son niveau cible
-- (en tenant compte des commandes de réassort déjà en cours)
create or replace function public.restock_needs(p_shop uuid)
returns table (recipe_id uuid, missing numeric)
language sql stable security definer set search_path = public as $$
  select s.recipe_id, ceil(s.target_qty - s.qty - coalesce(p.pending, 0)) as missing
  from public.shop_stock s
  join public.recipes r on r.id = s.recipe_id and r.active
  left join (
    select oi.recipe_id, sum(oi.quantity) as pending
    from public.order_items oi
    join public.orders o on o.id = oi.order_id
    where o.shop_id = p_shop and o.kind = 'reassort'
      and o.status in ('en_attente','en_production','prete')
    group by oi.recipe_id
  ) p on p.recipe_id = s.recipe_id
  where s.shop_id = p_shop
    and (public.is_staff() or public.my_shop() = p_shop)
    and s.target_qty - s.qty - coalesce(p.pending, 0) > 0
$$;

-- Compléter le stock d'un magasin : crée la commande de réassort automatiquement
create or replace function public.request_restock(p_shop uuid, p_due date default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare v_id bigint;
begin
  if not (public.is_staff() or (public.my_role() = 'magasin' and public.my_shop() = p_shop)) then
    raise exception 'Accès refusé pour ce magasin';
  end if;
  if not exists (select 1 from public.restock_needs(p_shop)) then
    raise exception 'Rien à compléter : le stock est au niveau cible (commandes en cours comprises)';
  end if;

  insert into public.orders (shop_id, kind, due_date, notes)
  values (p_shop, 'reassort', coalesce(p_due, current_date + 1), 'Complément automatique du stock')
  returning id into v_id;

  insert into public.order_items (order_id, recipe_id, quantity)
  select v_id, n.recipe_id, n.missing from public.restock_needs(p_shop) n;

  return v_id;
end $$;

-- Produire des fournées : retire les matières, ajoute au stock produit
create or replace function public.produce_recipe(p_recipe uuid, p_batches numeric, p_allow_negative boolean default false)
returns numeric language plpgsql security definer set search_path = public as $$
declare
  v_name    text;
  v_yield   numeric;
  v_missing text;
  v_cost    numeric;
  v_qty     numeric;
begin
  if not public.is_staff() then
    raise exception 'Accès réservé à la production';
  end if;
  if p_batches is null or p_batches <= 0 then
    raise exception 'Nombre de fournées invalide';
  end if;
  select name, yield_qty into v_name, v_yield from public.recipes where id = p_recipe;
  if not found then
    raise exception 'Recette introuvable';
  end if;

  select string_agg(a.name || ' (manque ' || round(n.need - a.stock, 3) || ' ' || a.unit || ')', ', ' order by a.name)
    into v_missing
  from (
    select ri.article_id, sum(ri.quantity / public.unit_factor(a2.unit)) * p_batches as need
    from public.recipe_items ri join public.articles a2 on a2.id = ri.article_id
    where ri.recipe_id = p_recipe
    group by ri.article_id
  ) n
  join public.articles a on a.id = n.article_id
  where a.stock < n.need;

  if v_missing is not null and not p_allow_negative then
    raise exception 'Stock insuffisant : %', v_missing;
  end if;

  select coalesce(sum(ri.quantity / public.unit_factor(a.unit) * a.price), 0) * p_batches
    into v_cost
  from public.recipe_items ri join public.articles a on a.id = ri.article_id
  where ri.recipe_id = p_recipe;

  update public.articles a
     set stock = a.stock - n.need
  from (
    select ri.article_id, sum(ri.quantity / public.unit_factor(a2.unit)) * p_batches as need
    from public.recipe_items ri join public.articles a2 on a2.id = ri.article_id
    where ri.recipe_id = p_recipe
    group by ri.article_id
  ) n
  where a.id = n.article_id;

  v_qty := v_yield * p_batches;

  insert into public.production_stock (recipe_id, qty) values (p_recipe, v_qty)
  on conflict (recipe_id) do update
    set qty = public.production_stock.qty + excluded.qty, updated_at = now();

  insert into public.production_batches (recipe_id, recipe_name, batches, qty, cost)
  values (p_recipe, v_name, p_batches, v_qty, round(v_cost, 2));

  return v_qty;
end $$;

-- Livrer une commande : retire du stock produit, ajoute au stock du magasin (réassort)
create or replace function public.deliver_order(p_order bigint, p_allow_negative boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_shop    uuid;
  v_kind    text;
  v_status  text;
  v_missing text;
begin
  if not public.is_staff() then
    raise exception 'Accès réservé à la production';
  end if;
  select shop_id, kind, status into v_shop, v_kind, v_status
  from public.orders where id = p_order for update;
  if not found then
    raise exception 'Commande introuvable';
  end if;
  if v_status in ('livree','annulee') then
    raise exception 'Cette commande est déjà %', case v_status when 'livree' then 'livrée' else 'annulée' end;
  end if;

  select string_agg(r.name || ' (dispo ' || coalesce(ps.qty, 0) || ', demandé ' || oi.quantity || ')', ', ' order by r.name)
    into v_missing
  from (select x.recipe_id, sum(x.quantity) as quantity from public.order_items x where x.order_id = p_order group by x.recipe_id) oi
  join public.recipes r on r.id = oi.recipe_id
  left join public.production_stock ps on ps.recipe_id = oi.recipe_id
  where coalesce(ps.qty, 0) < oi.quantity;

  if v_missing is not null and not p_allow_negative then
    raise exception 'Stock produit insuffisant : %', v_missing;
  end if;

  insert into public.production_stock (recipe_id, qty)
  select x.recipe_id, -sum(x.quantity) from public.order_items x where x.order_id = p_order group by x.recipe_id
  on conflict (recipe_id) do update
    set qty = public.production_stock.qty + excluded.qty, updated_at = now();

  if v_kind = 'reassort' then
    insert into public.shop_stock (shop_id, recipe_id, qty)
    select v_shop, x.recipe_id, sum(x.quantity) from public.order_items x where x.order_id = p_order group by x.recipe_id
    on conflict (shop_id, recipe_id) do update
      set qty = public.shop_stock.qty + excluded.qty, updated_at = now();
  end if;

  update public.orders set status = 'livree', delivered_at = now() where id = p_order;
end $$;

-- Mouvements de stock (réception, perte, vente, inventaire)
create or replace function public.adjust_article_stock(p_article uuid, p_delta numeric)
returns numeric language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if not public.is_staff() then raise exception 'Accès réservé à la production'; end if;
  update public.articles set stock = stock + p_delta where id = p_article returning stock into v;
  if not found then raise exception 'Article introuvable'; end if;
  return v;
end $$;

create or replace function public.adjust_product_stock(p_recipe uuid, p_delta numeric)
returns numeric language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if not public.is_staff() then raise exception 'Accès réservé à la production'; end if;
  insert into public.production_stock (recipe_id, qty) values (p_recipe, p_delta)
  on conflict (recipe_id) do update
    set qty = public.production_stock.qty + excluded.qty, updated_at = now()
  returning qty into v;
  return v;
end $$;

create or replace function public.adjust_shop_stock(p_shop uuid, p_recipe uuid, p_delta numeric)
returns numeric language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if not (public.is_staff() or (public.my_role() = 'magasin' and public.my_shop() = p_shop)) then
    raise exception 'Accès refusé pour ce magasin';
  end if;
  insert into public.shop_stock (shop_id, recipe_id, qty) values (p_shop, p_recipe, p_delta)
  on conflict (shop_id, recipe_id) do update
    set qty = public.shop_stock.qty + excluded.qty, updated_at = now()
  returning qty into v;
  return v;
end $$;

-- Enregistrer une recette et ses ingrédients en une seule opération
create or replace function public.save_recipe(p_id uuid, p_recipe jsonb, p_items jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := p_id;
begin
  if not public.is_staff() then raise exception 'Accès réservé à la production'; end if;
  if coalesce(trim(p_recipe->>'name'), '') = '' then
    raise exception 'Le nom de la recette est obligatoire';
  end if;

  if v_id is null then
    insert into public.recipes (name, category, yield_qty, sale_price, extra_allergens, traces, instructions, active)
    values (
      trim(p_recipe->>'name'),
      nullif(trim(p_recipe->>'category'), ''),
      coalesce((p_recipe->>'yield_qty')::numeric, 1),
      coalesce((p_recipe->>'sale_price')::numeric, 0),
      coalesce(array(select jsonb_array_elements_text(coalesce(p_recipe->'extra_allergens', '[]'::jsonb))), '{}'),
      coalesce(array(select jsonb_array_elements_text(coalesce(p_recipe->'traces', '[]'::jsonb))), '{}'),
      p_recipe->>'instructions',
      coalesce((p_recipe->>'active')::boolean, true))
    returning id into v_id;
  else
    update public.recipes set
      name            = trim(p_recipe->>'name'),
      category        = nullif(trim(p_recipe->>'category'), ''),
      yield_qty       = coalesce((p_recipe->>'yield_qty')::numeric, 1),
      sale_price      = coalesce((p_recipe->>'sale_price')::numeric, 0),
      extra_allergens = coalesce(array(select jsonb_array_elements_text(coalesce(p_recipe->'extra_allergens', '[]'::jsonb))), '{}'),
      traces          = coalesce(array(select jsonb_array_elements_text(coalesce(p_recipe->'traces', '[]'::jsonb))), '{}'),
      instructions    = p_recipe->>'instructions',
      active          = coalesce((p_recipe->>'active')::boolean, true)
    where id = v_id;
    if not found then raise exception 'Recette introuvable'; end if;
  end if;

  delete from public.recipe_items where recipe_id = v_id;
  insert into public.recipe_items (recipe_id, article_id, quantity)
  select v_id, (e->>'article_id')::uuid, sum((e->>'quantity')::numeric)
  from jsonb_array_elements(coalesce(p_items, '[]'::jsonb)) e
  where e->>'article_id' is not null and (e->>'quantity')::numeric > 0
  group by (e->>'article_id')::uuid;

  return v_id;
end $$;

grant execute on function
  public.create_order(uuid, text, date, jsonb, text, text, text),
  public.restock_needs(uuid),
  public.request_restock(uuid, date),
  public.produce_recipe(uuid, numeric, boolean),
  public.deliver_order(bigint, boolean),
  public.adjust_article_stock(uuid, numeric),
  public.adjust_product_stock(uuid, numeric),
  public.adjust_shop_stock(uuid, uuid, numeric),
  public.save_recipe(uuid, jsonb, jsonb)
to authenticated;

-- ---------------------------------------------------------------------
-- TEMPS RÉEL : la production voit arriver les commandes sans recharger
-- ---------------------------------------------------------------------
do $$
begin
  alter publication supabase_realtime add table public.orders;
exception when others then null;
end $$;

-- ---------------------------------------------------------------------
-- DONNÉES DE DÉPART : les deux magasins (renommables dans l'onglet Comptes)
-- ---------------------------------------------------------------------
insert into public.shops (name) values ('Magasin 1'), ('Magasin 2')
on conflict (name) do nothing;

-- =====================================================================
-- APRÈS LE PREMIER LANCEMENT :
--   1. Supabase > Authentication > Users > "Add user" : créez le compte production
--      (cochez "Auto Confirm User").
--   2. Donnez-lui le rôle production :
--        update public.profiles set role = 'production' where email = 'votre@email.be';
--   3. Connectez-vous sur le site : les comptes magasins se créent ensuite
--      depuis l'onglet « Comptes ».
-- =====================================================================
