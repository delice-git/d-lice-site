# Le Temps d'un Délice — gestion de boulangerie

Site de gestion pour deux magasins (ou plus) et un atelier de production.
React + Vite côté site, Supabase pour les comptes et la base de données, Vercel pour l'hébergement.

## Ce que fait le site

**Comptes magasin** (un compte par magasin, chacun ne voit que le sien)
- **Mon stock** : stock de chaque produit, boutons −/+ pour les ventes, niveau cible.
  « Compléter le stock » crée seul la commande de ce qui manque pour revenir au niveau cible
  (les commandes déjà en cours sont déduites).
- **Commandes** : réassort ou commande client (nom, téléphone, date de retrait, remarque), envoyées à la production.
- **Allergènes** : tableau des 14 allergènes par recette, filtre « mon client est allergique à… », impression.

**Compte production** (accès à tout)
- **Tableau de bord** : commandes à prendre en charge, livraisons du jour, matières à racheter.
- **Commandes** : toutes les commandes en direct, statuts En attente → En production → Prête → Livrée.
  La livraison retire du stock produit et ajoute au stock du magasin. Tableau « à produire » avec le nombre de fournées.
- **Agenda** : événements de l'atelier + commandes à livrer jour par jour.
- **Recettes** : ingrédients tirés du stock matières, coût par fournée et par pièce, marge,
  allergènes calculés automatiquement, simulation et lancement d'une production (retire les matières, ajoute au stock produit).
- **Stock matières** : articles (kg, L, pièce), prix, minimum, allergènes, entrées/sorties/inventaire.
- **Stock produits** : produits finis à l'atelier, réservé par les commandes, historique des fournées.
- **Stocks magasins** : vue comparée des magasins et gestion de chacun.
- **Comptes & magasins** : créer les comptes, attribuer rôle et magasin, renommer/ajouter des magasins.

## Mise en ligne (≈ 15 minutes)

### 1. Supabase
1. Créez un projet sur https://supabase.com (région Europe).
2. **SQL Editor → New query** : collez tout `supabase/schema.sql`, cliquez **Run**.
3. Facultatif : collez `supabase/seed.sql` pour avoir des articles et recettes d'exemple.
4. **Authentication → Users → Add user** : créez le compte de la production (cochez *Auto Confirm User*).
5. Dans le SQL Editor, donnez-lui le rôle production :
   ```sql
   update public.profiles set role = 'production' where email = 'votre@email.be';
   ```
6. **Authentication → Providers → Email** : désactivez *Allow new users to sign up*
   (seule la production crée les comptes).
7. Notez dans **Project Settings → API** : l'URL du projet, la clé `anon` et la clé `service_role`.

### 2. Vercel
1. Mettez ce dossier sur GitHub, puis **Vercel → Add New → Project** et importez-le (Vercel détecte Vite).
2. **Environment Variables** :
   | Nom | Valeur |
   |---|---|
   | `VITE_SUPABASE_URL` | URL du projet |
   | `VITE_SUPABASE_ANON_KEY` | clé `anon` |
   | `SUPABASE_SERVICE_ROLE_KEY` | clé `service_role` (reste côté serveur, sert à créer les comptes) |
3. **Deploy**. Connectez-vous avec le compte production, puis créez les comptes des deux magasins
   dans **Comptes & magasins** (renommez « Magasin 1 » et « Magasin 2 » au passage).

### En local
```bash
cp .env.example .env    # puis remplissez les valeurs
npm install
npm run dev
```
En local, la création de comptes depuis le site ne marche qu'avec `vercel dev`.
Sinon, créez le compte dans Supabase : il apparaît dans « Comptes & magasins » en attente, il suffit de lui donner un rôle.

## Sécurité
Toutes les règles d'accès sont dans la base (Row Level Security), pas seulement dans le site :
un compte magasin ne peut ni lire ni modifier le stock ou les commandes d'un autre magasin,
ni toucher aux recettes, au stock matières ou à l'agenda. Les opérations sensibles
(produire, livrer, compléter le stock) passent par des fonctions SQL qui vérifient le rôle.

## Unités
Un article est stocké en **kg**, **L** ou **pièce**. Dans les recettes, on saisit en **g**, **ml** ou **pièces** ;
la conversion est faite automatiquement pour les coûts et les sorties de stock.
